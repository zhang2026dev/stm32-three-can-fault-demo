#ifndef _CAN_DRIVER_H
#define _CAN_DRIVER_H

#include "main.h"
extern CAN_HandleTypeDef hcan;

void CAN_TX(CAN_TxHeaderTypeDef *txHeader, uint8_t *ltxData, uint8_t len);
uint8_t CAN_RX(CAN_RxHeaderTypeDef *rxHeader, uint8_t *lrxData);
void CAN_Init(void);
#endif