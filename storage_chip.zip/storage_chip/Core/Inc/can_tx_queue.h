#ifndef CAN_TX_QUEUE_H
#define CAN_TX_QUEUE_H

#include "FreeRTOS.h"
#include "queue.h"
#include "can_driver.h"

// CAN消息类型
typedef enum {
    MSG_TYPE_SERVO = 0,
    MSG_TYPE_FAULT,
    MSG_TYPE_HISTORY_ADC,
    MSG_TYPE_HISTORY_CAN,
} CanMsgType_t;

// CAN发送消息结构体
typedef struct {
    CanMsgType_t type;
    uint32_t id;
    uint8_t data[8];
    uint8_t dlc;
} CanTxMsg_t;

void CAN_Tx_Queue_Init(void);
void CAN_Send_To_Queue(uint32_t id, uint8_t *data, uint8_t dlc, CanMsgType_t type);

#endif