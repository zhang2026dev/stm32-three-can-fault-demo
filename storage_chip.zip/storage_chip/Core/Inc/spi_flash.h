#ifndef SPI_FLASH_H
#define SPI_FLASH_H

#include "main.h"

// SPI Flash 设备结构体
typedef struct {
    SPI_HandleTypeDef *hspi;   // SPI 句柄
    GPIO_TypeDef *cs_port;      // CS 引脚端口
    uint16_t cs_pin;            // CS 引脚号
} SPI_Flash_Dev;

// 函数声明
extern SPI_Flash_Dev flash_dev;
void SPI_Flash_Init(SPI_Flash_Dev *dev, SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin);
void SPI_Flash_Read_ID(SPI_Flash_Dev *dev, uint8_t *id_buf);
void SPI_Flash_Writ_Enable(SPI_Flash_Dev *dev);
void SPI_Flash_Wait_Busy(SPI_Flash_Dev *dev);
void SPI_Flash_Erase_Sector(SPI_Flash_Dev *dev, uint32_t addr);
void SPI_Flash_Write(SPI_Flash_Dev *dev, uint32_t addr, void *data, uint16_t len);
void SPI_Flash_Read(SPI_Flash_Dev *dev, uint32_t addr, void *data, uint16_t len);
#endif