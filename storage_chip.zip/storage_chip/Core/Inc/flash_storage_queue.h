#ifndef FLASH_STORAGE_QUEUE_H
#define FLASH_STORAGE_QUEUE_H

#include "FreeRTOS.h"
#include "queue.h"
#include "semphr.h"
#include "spi_flash.h"

#define FLASH_STORAGE_DEPTH  10

// 数据类型（用于区分ADC和错误数据）
typedef enum {
    DATA_TYPE_ADC = 0,
    DATA_TYPE_CAN_ERR,
} DataType_t;

// 存储数据结构体（8字节，对齐CAN数据）
typedef struct {
    DataType_t type;          // 数据类型
    uint16_t adc[3];          // ADC值 或 错误码
    uint16_t timestamp;       // 时间戳
} StorageData_t;

// 环形缓冲区结构体
typedef struct {
    StorageData_t buf[FLASH_STORAGE_DEPTH];
    uint8_t write_idx;
    uint8_t valid_cnt;
    SemaphoreHandle_t mutex;
} FlashRingBuffer_t;

extern QueueHandle_t g_flash_queue;
extern FlashRingBuffer_t g_flash_ring;
extern SPI_Flash_Dev flash_dev1;
extern SPI_Flash_Dev flash_dev2;

#define FLASH_STORAGE_BASE_ADDR  0x001000

void Flash_Storage_Init(void);
BaseType_t Flash_Send_To_Queue(StorageData_t *pData);
void Flash_Write_Task(void *pvParameters);
void Flash_Report_Task(void *pvParameters);

#endif