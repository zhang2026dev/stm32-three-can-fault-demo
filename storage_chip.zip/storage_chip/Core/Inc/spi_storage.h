#ifndef SPI_FLASH_H
#define SPI_FLASH_H

#include "main.h"

typedef struct {
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef *cs_port;
    uint16_t cs_pin;
} SPI_Flash_Dev;

// ★ 声明两个 Flash 设备
extern SPI_Flash_Dev flash_dev1;
extern SPI_Flash_Dev flash_dev2;

void SPI_Flash_Init(SPI_Flash_Dev *dev, SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin);
void SPI_Flash_Read_ID(SPI_Flash_Dev *dev, uint8_t *id_buf);
void SPI_Flash_Writ_Enable(SPI_Flash_Dev *dev);
void SPI_Flash_Wait_Busy(SPI_Flash_Dev *dev);
void SPI_Flash_Erase_Sector(SPI_Flash_Dev *dev, uint32_t addr);
void SPI_Flash_Write(SPI_Flash_Dev *dev, uint32_t addr, void *data, uint16_t len);
void SPI_Flash_Read(SPI_Flash_Dev *dev, uint32_t addr, void *data, uint16_t len);
void spi_storage_init(void);
#endif