/* my_debug.h */
#ifndef __MY_DEBUG_H
#define __MY_DEBUG_H

#include "main.h" // 确保包含 HAL 定义
#include <stdio.h>
#include <stdarg.h>
#ifdef __cplusplus
extern "C" {
#endif

// 声明函数
void uart_printf(const char *format, ...);
void uart_printf_init(UART_HandleTypeDef *huart);

#ifdef __cplusplus
}
#endif

#endif /* __MY_DEBUG_H */