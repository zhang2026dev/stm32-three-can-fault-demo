#ifndef CAN_PROTOCOL_H
#define CAN_PROTOCOL_H

#include "main.h"
void PROTOCOL_HandleMsg(uint32_t id,uint8_t *data,uint8_t len);

#endif