 #ifndef _CAN_TASK_H
 #define _CAN_TASK_H

 #include "main.h"
void can_task(void *pvParameters);
 extern uint16_t CAN_ADC[3];
 
 #endif