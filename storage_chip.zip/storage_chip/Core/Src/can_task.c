#include "main.h"
#include "can_driver.h"
#include "my_debug.h"
#include "spi_flash.h"
#include "spi_storage.h"
#include "flash_storage_queue.h"

extern SPI_Flash_Dev flash_dev;
extern uint32_t storage_addr[3];
extern uint8_t storage_idx;
static uint8_t send_idx = 0;

void can_task(void *pvParameters) 
{
		uart_printf("进入can_task\n");
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];
    uint32_t last_send = 0;
    
    while (1) {
			//接收数据并且打印
        if (CAN_RX(&rxHeader, rxData)) {
            uart_printf("[can_task] 收到 ID=0x%03X, DLC=%d, data: ", rxHeader.StdId, rxHeader.DLC);
            for (int i = 0; i < rxHeader.DLC; i++) {
                uart_printf("%02X ", rxData[i]);
            }
            uart_printf("\r\n");
						//收到0x222 adc数据 打包类型adc 
            if (rxHeader.StdId == 0x222 && rxHeader.DLC >= 6) {
								uart_printf("收到222\n");
                StorageData_t data;
                data.type = DATA_TYPE_ADC;
                data.adc[0] = (rxData[0] << 8) | rxData[1];
                data.adc[1] = (rxData[2] << 8) | rxData[3];
                data.adc[2] = (rxData[4] << 8) | rxData[5];
                data.timestamp = (uint16_t)(HAL_GetTick() / 1000);

                uart_printf("[can_task] ADC 入队: %d, %d, %d, time=%d\r\n", 
                    data.adc[0], data.adc[1], data.adc[2], data.timestamp);
								
							//放队列
                if (Flash_Send_To_Queue(&data) == pdPASS) {
                    uart_printf("[QUEUE] ADC 入队成功\n");
                } else {
                    uart_printf("[QUEUE] ADC 入队失败！\n");
                }
            }
            
            // 0x223 错误数据 打包类型错误 
            if (rxHeader.StdId == 0x223 && rxHeader.DLC >= 6) {
								uart_printf("收到223\n");
                StorageData_t data;
                data.type = DATA_TYPE_CAN_ERR;
                data.adc[0] = (rxData[0] << 8) | rxData[1];
                data.adc[1] = (rxData[2] << 8) | rxData[3];
                data.adc[2] = (rxData[4] << 8) | rxData[5];
                data.timestamp = (uint16_t)(HAL_GetTick() / 1000);

                uart_printf("[can_task] CAN错误入队: %d, %d, %d, time=%d\r\n", 
                    data.adc[0], data.adc[1], data.adc[2], data.timestamp);

                if (Flash_Send_To_Queue(&data) != pdPASS) {
                    uart_printf("[can_task] CAN错误队列满，丢弃\r\n");
                }
            }
        }
        HAL_IWDG_Refresh(&hiwdg);
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}