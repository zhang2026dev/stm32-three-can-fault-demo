#include "spi_flash.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"

// CS 控制宏（内联，提高效率）
static inline void CS_Low(SPI_Flash_Dev *dev) {
    HAL_GPIO_WritePin(dev->cs_port, dev->cs_pin, GPIO_PIN_RESET);
}

static inline void CS_High(SPI_Flash_Dev *dev) {
    HAL_GPIO_WritePin(dev->cs_port, dev->cs_pin, GPIO_PIN_SET);
}

// 初始化设备
void SPI_Flash_Init(SPI_Flash_Dev *dev, SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin)
{
    dev->hspi = hspi;
    dev->cs_port = cs_port;
    dev->cs_pin = cs_pin;
    
    // 拉高 CS，默认不选中
    CS_High(dev);
}

// 读 ID
void SPI_Flash_Read_ID(SPI_Flash_Dev *dev, uint8_t *id_buf)
{
    uint8_t cmd = 0x9F;
    
    CS_Low(dev);
    HAL_SPI_Transmit(dev->hspi, &cmd, 1, 100);
    HAL_SPI_Receive(dev->hspi, id_buf, 3, 100);  // ID 通常是 3 字节
    CS_High(dev);
}

// 写使能
void SPI_Flash_Writ_Enable(SPI_Flash_Dev *dev)
{
    uint8_t cmd = 0x06;
    CS_Low(dev);
    HAL_SPI_Transmit(dev->hspi, &cmd, 1, 100);
    CS_High(dev);
		 vTaskDelay(pdMS_TO_TICKS(100));
}

// 等待空闲
void SPI_Flash_Wait_Busy(SPI_Flash_Dev *dev)
{
    uint8_t cmd = 0x05;
    uint8_t status = 0;
    uint16_t timeout = 10000;
    
    do {
        CS_Low(dev);
        HAL_SPI_Transmit(dev->hspi, &cmd, 1, 100);
        HAL_SPI_Receive(dev->hspi, &status, 1, 100);
        CS_High(dev);
        
        if (--timeout == 0) {
            uart_printf("SPI Flash 等待超时\n");
            break;
        }
    } while (status & 0x01);
}

// 擦除扇区（4KB）
void SPI_Flash_Erase_Sector(SPI_Flash_Dev *dev, uint32_t addr)
{
    uint8_t cmd[4] = {0x20, (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF};
    
    SPI_Flash_Writ_Enable(dev);
    CS_Low(dev);
    HAL_SPI_Transmit(dev->hspi, cmd, 4, 100);
    CS_High(dev);
    SPI_Flash_Wait_Busy(dev);
		 vTaskDelay(pdMS_TO_TICKS(100));
}

// 写数据
void SPI_Flash_Write(SPI_Flash_Dev *dev, uint32_t addr, void *data, uint16_t len)
{
    uart_printf("[SPI_Write] 进入函数, addr=0x%06X, len=%d\n", addr, len);
    
    uint8_t cmd[4] = {0x02, (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF};
    uint8_t *p = (uint8_t*)data;
    
    uart_printf("[SPI_Write] 写使能...\n");
    SPI_Flash_Writ_Enable(dev);
    uart_printf("[SPI_Write] 写使能完成\n");
    
    uart_printf("[SPI_Write] CS Low...\n");
    CS_Low(dev);
    HAL_SPI_Transmit(dev->hspi, cmd, 4, 100);
    HAL_SPI_Transmit(dev->hspi, p, len, 100);
    CS_High(dev);
    SPI_Flash_Wait_Busy(dev);
    vTaskDelay(pdMS_TO_TICKS(100));
    uart_printf("[SPI_Write] 函数退出\n");
}

// 读数据
void SPI_Flash_Read(SPI_Flash_Dev *dev, uint32_t addr, void *data, uint16_t len)
{
//    uart_printf("SPI_Flash_Read 执行了, addr=0x%06X\n", addr);
    uint8_t cmd[4] = {0x03, (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF};
    uint8_t *p = (uint8_t*)data;
    
    CS_Low(dev);
    HAL_SPI_Transmit(dev->hspi, cmd, 4, 100);
    HAL_StatusTypeDef ret = HAL_SPI_Receive(dev->hspi, p, len, 100);
    CS_High(dev);
    
//    uart_printf("SPI_Receive ret=%d\n", ret);
//    uart_printf("SPI_Flash_Read 完成\n");
		 vTaskDelay(pdMS_TO_TICKS(100));
}
