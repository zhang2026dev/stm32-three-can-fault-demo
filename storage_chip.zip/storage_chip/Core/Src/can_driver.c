 #include "can_driver.h"
 #include "main.h"
 #include "my_debug.h"

 void CAN_TX(CAN_TxHeaderTypeDef *txHeader,uint8_t *ltxData,uint8_t len)
 {
  uint32_t txMailbox;
  if (HAL_CAN_AddTxMessage(&hcan,txHeader,ltxData,&txMailbox) == HAL_OK)
  {
    for(uint8_t i = 0 ; i<len; i++) uart_printf("%02X",ltxData[i]);
    uart_printf("\n");
  }
 }

 uint8_t CAN_RX(CAN_RxHeaderTypeDef *lrxHeader ,uint8_t *rxData)
 {
  if(HAL_CAN_GetRxMessage(&hcan,CAN_RX_FIFO0,lrxHeader,rxData) == HAL_OK)
  {
    for(uint8_t i = 0;i<lrxHeader->DLC;i++) uart_printf("%02X",rxData[i]);
    uart_printf("\n");
    return 1;
  }
  return 0;
 }

void CAN_Init(void)
{
    CAN_FilterTypeDef sFilterConfig;
    
    // 设置为不过滤任何 ID，全部接收
    sFilterConfig.FilterBank = 0;
    sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
    sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
    sFilterConfig.FilterIdHigh = 0x0000;
    sFilterConfig.FilterIdLow = 0x0000;
    sFilterConfig.FilterMaskIdHigh = 0x0000;   // 全0 = 不过滤
    sFilterConfig.FilterMaskIdLow = 0x0000;
    sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
    sFilterConfig.FilterActivation = ENABLE;
    
    if (HAL_CAN_ConfigFilter(&hcan, &sFilterConfig) != HAL_OK) {
        while(1);
    }
    
    HAL_CAN_Start(&hcan);
}
