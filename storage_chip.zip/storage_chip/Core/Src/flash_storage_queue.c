#include "flash_storage_queue.h"
#include "spi_flash.h"
#include "spi_storage.h"
#include "my_debug.h"
#include "can_driver.h"
#include "can_tx_queue.h"

extern SPI_Flash_Dev flash_dev1;
extern SPI_Flash_Dev flash_dev2;

QueueHandle_t g_flash_queue = NULL;
FlashRingBuffer_t g_flash_ring = {0};

// 启动队列 互斥锁
void Flash_Storage_Init(void)
{
    g_flash_ring.mutex = xSemaphoreCreateMutex();
    g_flash_queue = xQueueCreate(10, sizeof(StorageData_t));

    xTaskCreate(Flash_Write_Task, "FlashWrite", 512, NULL, 2, NULL);
    xTaskCreate(Flash_Report_Task, "FlashReport", 512, NULL, 1, NULL);
}

// 入队
BaseType_t Flash_Send_To_Queue(StorageData_t *pData)
{
    if (g_flash_queue == NULL) return pdFAIL;
    return xQueueSend(g_flash_queue, pData, 0);
}

//取数据 更新缓冲区 打包写入  
void Flash_Write_Task(void *pvParameters)
{
    (void)pvParameters;
    StorageData_t recv_data;
    uint8_t buf[8];
    uint8_t verify_buf[8];

    uart_printf("[WRITE] Flash_Write_Task 已启动\n");

    for (;;) {
        if (xQueueReceive(g_flash_queue, &recv_data, portMAX_DELAY) == pdPASS) {
            uart_printf("[WRITE] 取出队列: type=%d, adc=[%d,%d,%d]\n",
                recv_data.type,
                recv_data.adc[0], recv_data.adc[1], recv_data.adc[2]);

            // 更新 RAM 缓冲区
            xSemaphoreTake(g_flash_ring.mutex, portMAX_DELAY);
            g_flash_ring.buf[g_flash_ring.write_idx] = recv_data;
            g_flash_ring.write_idx = (g_flash_ring.write_idx + 1) % FLASH_STORAGE_DEPTH;
            if (g_flash_ring.valid_cnt < FLASH_STORAGE_DEPTH) {
                g_flash_ring.valid_cnt++;
            }
            xSemaphoreGive(g_flash_ring.mutex);

            // 计算地址
            uint32_t addr = FLASH_STORAGE_BASE_ADDR + (g_flash_ring.write_idx - 1) * 8;
            uart_printf("[WRITE] 地址: 0x%06X\n", addr);

            // 打包数据
            if (recv_data.type == DATA_TYPE_ADC) {
                buf[0] = 0x00;
                buf[1] = recv_data.adc[0] >> 8;
                buf[2] = recv_data.adc[0] & 0xFF;
                buf[3] = recv_data.adc[1] >> 8;
                buf[4] = recv_data.adc[1] & 0xFF;
                buf[5] = recv_data.adc[2] >> 8;
                buf[6] = recv_data.adc[2] & 0xFF;
                buf[7] = recv_data.timestamp & 0xFF;
            } else {
                buf[0] = 0x02;
                buf[1] = recv_data.adc[0] >> 8;
                buf[2] = recv_data.adc[0] & 0xFF;
                buf[3] = recv_data.adc[1] >> 8;
                buf[4] = recv_data.adc[1] & 0xFF;
                buf[5] = recv_data.adc[2] >> 8;
                buf[6] = recv_data.adc[2] & 0xFF;
                buf[7] = recv_data.timestamp & 0xFF;
            }

            uart_printf("[WRITE] 打包数据: ");
            for (int i = 0; i < 8; i++) uart_printf("%02X ", buf[i]);
            uart_printf("\n");

            // 写入 SPI
            xSemaphoreTake(g_flash_ring.mutex, portMAX_DELAY);

            if (recv_data.type == DATA_TYPE_ADC) {
                // ★★★ 写入前先擦除扇区 ★★★
                uart_printf("[WRITE] SPI2 擦除扇区: addr=0x%06X\n", addr);
                SPI_Flash_Erase_Sector(&flash_dev2, addr);
                uart_printf("[WRITE] SPI2 擦除完成\n");

                SPI_Flash_Write(&flash_dev2, addr, buf, 8);
                uart_printf("[WRITE] SPI2 写入完成\n");

                SPI_Flash_Read(&flash_dev2, addr, verify_buf, 8);
                uart_printf("[WRITE] 验证读出 SPI2: ");
                for (int i = 0; i < 8; i++) uart_printf("%02X ", verify_buf[i]);
                uart_printf("\n");

            } else {
                // ★★★ 故障数据：写入 SPI1，也先擦除 ★★★
                uart_printf("[WRITE] SPI1 擦除扇区: addr=0x%06X\n", addr);
                SPI_Flash_Erase_Sector(&flash_dev1, addr);
                uart_printf("[WRITE] SPI1 擦除完成\n");

                SPI_Flash_Write(&flash_dev1, addr, buf, 8);
                uart_printf("[WRITE] SPI1 写入完成\n");

                SPI_Flash_Read(&flash_dev1, addr, verify_buf, 8);
                uart_printf("[WRITE] 验证读出 SPI1: ");
                for (int i = 0; i < 8; i++) uart_printf("%02X ", verify_buf[i]);
                uart_printf("\n");
            }

            xSemaphoreGive(g_flash_ring.mutex);
        }

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

//读数据 
void Flash_Report_Task(void *pvParameters)
{
    (void)pvParameters;
    uint8_t buf[8];

    uart_printf("[REPORT] Flash_Report_Task 已启动\n");

    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(3000));

        uart_printf("[REPORT] === 上报开始 ===\n");

        // ====== 1. 从 SPI2 读取 ADC 历史数据 ======
        uart_printf("[REPORT] --- 读取 SPI2 (ADC 历史) ---\n");
        for (uint8_t i = 0; i < FLASH_STORAGE_DEPTH; i++) {
            uint32_t addr = FLASH_STORAGE_BASE_ADDR + i * 8;
            SPI_Flash_Read(&flash_dev2, addr, buf, 8);

            if (buf[0] == 0x00) {
                uart_printf("[REPORT] SPI2 读出: ");
                for (int j = 0; j < 8; j++) uart_printf("%02X ", buf[j]);
                uart_printf("\n");

                // ★★★ 清除时间戳（最后2字节）★★★
                buf[6] = 0x00;
                buf[7] = 0x00;

                CAN_Send_To_Queue(0x129, buf, 8, MSG_TYPE_HISTORY_ADC);
                uart_printf("[REPORT] ADC 上报发送 (ID=0x129)\n");
            }
        }

        // ====== 2. 从 SPI1 读取 CAN 错误历史数据 ======
        uart_printf("[REPORT] --- 读取 SPI1 (CAN 错误历史) ---\n");
        for (uint8_t i = 0; i < FLASH_STORAGE_DEPTH; i++) {
            uint32_t addr = FLASH_STORAGE_BASE_ADDR + i * 8;
            SPI_Flash_Read(&flash_dev1, addr, buf, 8);

            if (buf[0] == 0x02) {
                uart_printf("[REPORT] SPI1 读出: ");
                for (int j = 0; j < 8; j++) uart_printf("%02X ", buf[j]);
                uart_printf("\n");

                // ★★★ 清除时间戳（最后2字节）★★★
                buf[6] = 0x00;
                buf[7] = 0x00;

                CAN_Send_To_Queue(0x12A, buf, 8, MSG_TYPE_HISTORY_CAN);
                uart_printf("[REPORT] CAN 错误上报发送 (ID=0x12A)\n");
            }
        }

        uart_printf("[REPORT] === 上报完成 ===\n");
    }
}