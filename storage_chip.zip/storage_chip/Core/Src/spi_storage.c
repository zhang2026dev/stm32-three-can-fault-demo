// spi_storage.c
#include "spi_storage.h"
#include "spi_flash.h"
#include "my_debug.h"

extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;

// ★ 定义两个 Flash 设备
SPI_Flash_Dev flash_dev1;
SPI_Flash_Dev flash_dev2;

// 统一地址数组（3个地址，每个8字节）
uint32_t storage_addr[3] = {0x001000, 0x001008, 0x001010};
uint8_t storage_idx = 0;

void spi_storage_init(void)
{
    uart_printf("spi_storage_init\n");
    
    SPI_Flash_Init(&flash_dev1, &hspi1, GPIOB, GPIO_PIN_0);
    SPI_Flash_Init(&flash_dev2, &hspi2, GPIOA, GPIO_PIN_8);
    
    // ★★★ 读 SPI1 的 ID ★★★
    uint8_t id1[3];
    SPI_Flash_Read_ID(&flash_dev1, id1);
    uart_printf("SPI1 ID: %02X %02X %02X\n", id1[0], id1[1], id1[2]);
    
    // ★★★ 读 SPI2 的 ID ★★★
    uint8_t id2[3];
    SPI_Flash_Read_ID(&flash_dev2, id2);
    uart_printf("SPI2 ID: %02X %02X %02X\n", id2[0], id2[1], id2[2]);
    
    uart_printf("spi_storage_init 完成\n");
}

// 写入数据（保留给控制芯片调用）
void spi_storage_save(uint16_t *adc) 
{
    uint8_t buf[8];
    uint16_t timestamp = (uint16_t)(HAL_GetTick() / 1000);
    
    buf[0] = adc[0] >> 8;
    buf[1] = adc[0] & 0xFF;
    buf[2] = adc[1] >> 8;
    buf[3] = adc[1] & 0xFF;
    buf[4] = adc[2] >> 8;
    buf[5] = adc[2] & 0xFF;
    buf[6] = timestamp >> 8;
    buf[7] = timestamp & 0xFF;
    
    // ★ 同时写入两个 Flash
    SPI_Flash_Write(&flash_dev1, storage_addr[storage_idx], buf, 8);
    SPI_Flash_Write(&flash_dev2, storage_addr[storage_idx], buf, 8);
    
    storage_idx = (storage_idx + 1) % 3;
}