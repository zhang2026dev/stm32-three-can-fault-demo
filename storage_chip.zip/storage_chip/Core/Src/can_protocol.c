#include "spi_flash.h"
#include "my_debug.h"
#include "can_driver.h"
#include "spi_storage.h"
#include "flash_storage_queue.h"   // ★ 新增（为了用互斥锁）

extern SPI_Flash_Dev flash_dev;

void PROTOCOL_HandleMsg(uint32_t id, uint8_t *data, uint8_t len)
{

}
/*
	  uart_printf_init(&huart2);
		uart_printf("初始化\n");
    // 1. SPI Flash 初始化
   spi_storage_init();
    // 2. CAN 硬件初始化
   CAN_Init();
    // 3. Flash 存储队列初始化（创建队列 + 互斥锁 + 写入任务 + 上报任务）
   Flash_Storage_Init();
    // 5. 创建 CAN 接收任务（原来的 can_task，改成任务形式）
   xTaskCreate(can_task, "can_task", 512, NULL, 3, NULL);
*/