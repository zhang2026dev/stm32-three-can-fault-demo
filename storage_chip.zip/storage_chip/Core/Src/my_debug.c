/* my_debug.c */
#include "my_debug.h"

static UART_HandleTypeDef *debug_huart = NULL;

// 初始化（在main中调用一次）
void uart_printf_init(UART_HandleTypeDef *huart)
{
    debug_huart = huart;
}

// 核心打印函数
void uart_printf(const char *format, ...)
{
    if(debug_huart == NULL) return;
    
    char buffer[256];
    va_list args;
    
    va_start(args, format);
    int len = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    if(len > 0 && len < sizeof(buffer))
    {
        HAL_UART_Transmit(debug_huart, (uint8_t*)buffer, len, HAL_MAX_DELAY);
    }
}