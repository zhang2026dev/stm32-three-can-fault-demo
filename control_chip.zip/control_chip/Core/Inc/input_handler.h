#ifndef __INPUT_HANDLER_H
#define __INPUT_HANDLER_H

#include "main.h"  // 包含 main.h 就能用里面的定义

// 获取输入事件
InputEvent input_get_event(void);

#endif