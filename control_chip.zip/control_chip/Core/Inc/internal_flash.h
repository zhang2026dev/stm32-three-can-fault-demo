#ifndef __INTERNAL_FLASH_H
#define __INTERNAL_FLASH_H

#include "stm32f1xx_hal.h"
#include "FreeRTOS.h"
#include "queue.h"

#define FAULT_BUF_MAX      2
#define INTERNAL_FLASH_FAULT_PAGE_ADDR  0x0800F000
#define FLASH_MAGIC        0x5A5A5A5A

// 故障类型枚举
typedef enum
{
    FAULT_NONE = 0,
    FAULT_CAN_ERR,
    FAULT_HEARTBEAT_TIMEOUT,
    FAULT_MENU_DEAD,
    FAULT_WDG_HW_RESET
} FaultType_t;

// 单条故障消息结构体（4字节对齐）
typedef struct __attribute__((aligned(4)))
{
    FaultType_t type;
    uint32_t err;
    uint32_t time;
    uint8_t  flag;
} FaultMsg_t;

// 环形缓冲区结构体（无锁版本）
typedef struct
{
    FaultMsg_t buf[FAULT_BUF_MAX];
    uint8_t write_index;
    uint8_t valid_cnt;
} FaultRingBuffer_t;

// 外部变量
extern QueueHandle_t g_fault_queue;
extern FaultRingBuffer_t g_ram_ring;
extern uint8_t g_sys_flag;

// 初始化接口
void InternalFlash_Init(void);
void Fault_QueueCreate(void);

// 队列接口
BaseType_t Fault_SendMsg(uint32_t time, FaultType_t type, uint32_t err, uint8_t flag);

// 环形缓冲区接口
uint8_t RingBuffer_Push(FaultMsg_t *pMsg);
uint8_t RingBuffer_GetCount(void);
uint8_t RingBuffer_IsFull(void);
void RingBuffer_Clear(void);
FaultRingBuffer_t* Fault_GetRingBuffer(void);
uint8_t RingBuffer_Pop(FaultMsg_t *pMsg);
void SendAllFaultsFromRing(void);
// Flash存储接口
HAL_StatusTypeDef Flash_Store_RingBuffer(void);
void Flash_Recover_RingBuffer(void);

#endif