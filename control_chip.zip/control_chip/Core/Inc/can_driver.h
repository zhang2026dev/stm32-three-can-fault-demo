#ifndef CAN_DRIVER_H
#define CAN_DRIVER_H

#include "main.h"

extern CAN_HandleTypeDef hcan;

void CAN_TX(CAN_TxHeaderTypeDef *txHeader, uint8_t *ltxData, uint8_t len);
uint8_t CAN_RX(CAN_RxHeaderTypeDef *rxHeader, uint8_t *lrxData);
void CAN_Init(void);
void CAN_SendData(uint32_t id, uint8_t *data, uint8_t len);  // 必须加这行！
#endif