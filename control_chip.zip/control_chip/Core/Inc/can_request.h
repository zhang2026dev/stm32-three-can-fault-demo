#ifndef CAN_REQUEST_H
#define CAN_REQUEST_H

#define CMD_GET_ADC_HIST   0x01
#define CMD_GET_CAN_HIST   0x02

void request_can_history(uint8_t page);
void request_adc_history(uint8_t page);

#endif