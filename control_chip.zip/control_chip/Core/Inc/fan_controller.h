#ifndef _FAN_CONTROLLER_H
#define _FAN_CONTROLLER_H

#include "main.h"

// 函数声明
void fan_controller_init(void);    // 初始化显示
void fan_controller_update(InputEvent event);  // 加参数
#endif
