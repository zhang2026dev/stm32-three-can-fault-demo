#ifndef CAN_TX_QUEUE_H
#define CAN_TX_QUEUE_H

#include "FreeRTOS.h"
#include "queue.h"
#include "can_driver.h"

// CAN消息类型
typedef enum {
    MSG_TYPE_SERVO = 0,       // 舵机指令
    MSG_TYPE_FAULT,           // 故障数据
    MSG_TYPE_HISTORY_ADC,     // ADC历史查询
    MSG_TYPE_HISTORY_CAN,     // CAN历史查询
} CanMsgType_t;

// CAN发送消息结构体
typedef struct {
    CanMsgType_t type;        // 消息类型
    uint32_t id;              // CAN ID
    uint8_t data[8];          // 数据
    uint8_t dlc;              // 数据长度
} CanTxMsg_t;

// 初始化CAN发送队列（在main中调用一次）
void CAN_Tx_Queue_Init(void);

// 通用发送接口
void CAN_Send_To_Queue(uint32_t id, uint8_t *data, uint8_t dlc, CanMsgType_t type);

#endif