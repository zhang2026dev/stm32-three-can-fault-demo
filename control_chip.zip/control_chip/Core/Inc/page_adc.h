#ifndef __PAGE_ADC_H
#define __PAGE_ADC_H

#include "main.h"
#include "input_handler.h"

uint8_t page_adc_enter(void);
void page_adc_exit(void);
uint8_t page_adc_handle_event(InputEvent ev);
void page_adc_auto_refresh(void);

#endif