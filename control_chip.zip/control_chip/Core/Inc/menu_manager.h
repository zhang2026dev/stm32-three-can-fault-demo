 #ifndef MENU_MANAGER_H
 #define MENU_MANAGER_H

 #include "main.h"
 void menu_show_main(void *pvParameters);
 extern uint32_t menu_last_tick;
 #endif
 
///* Start scheduler */
///**********************************************************
// 初始化 任务 
// ***********************************************************/
//uart_printf_init(&huart1);
//HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
//CAN_Init();                     // 驱动初始化 can
//OLED_Init();                    // 初始化 
//OLED_Clear();                   // 清屏

//// 创建任务
//xTaskCreate(can_task, "CAN_Task", 512, NULL, 2, NULL); 
//xTaskCreate(menu_show_main, "menu_show_main", 512, NULL, 1, NULL);


//osKernelStart();

///* Private function prototypes -----------------------------------------------*/
//  void SystemClock_Config(void);
// static void MX_GPIO_Init(void);
// static void MX_CAN_Init(void);
// static void MX_USART1_UART_Init(void);
// static void MX_I2C1_Init(void);
// static void MX_TIM3_Init(void);
// void StartDefaultTask(void *argument);
// void StartDefaultTask(void *argument);
// void can_task(void *pvParameters);
// void display_task(void);
// void menu_show_main(void *pvParameters);

///* USER CODE BEGIN PFP */