#include "main.h"
#include "internal_flash.h"
#ifndef __PAGE_SPI_H
#define __PAGE_SPI_H



extern FaultType_t g_sys_err_code;
extern uint8_t g_feed_dog_enable;//看门狗标准位
extern IWDG_HandleTypeDef hiwdg;



// 封装喂狗（带全局开关判断）
void IWDG_Feed(void);

// 上电读取硬件复位标志
void WDG_CheckHwReset(void);

//检测超时函数 
void	Detectionl(uint32_t timl,FaultType_t type,uint32_t serial,uint8_t flag);

#endif