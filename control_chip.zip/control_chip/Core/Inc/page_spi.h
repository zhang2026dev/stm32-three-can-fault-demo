#ifndef __PAGE_SPI_H
#define __PAGE_SPI_H

#include "main.h"
#include "input_handler.h"
#include "FreeRTOS.h"
#include "task.h"
#include "can_request.h"
uint8_t page_spi_enter(void);
void page_spi_exit(void);
uint8_t page_spi_handle_event(InputEvent ev);
#endif