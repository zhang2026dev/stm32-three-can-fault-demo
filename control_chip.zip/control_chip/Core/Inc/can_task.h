#ifndef CAN_TASK_H
#define CAN_TASK_H

#include "main.h"

void CAN_rx(void *pvParameters);
void can_task(void *pvParameters);
void CAN_rx_Cs(void *pvParameters);

typedef struct {
    uint16_t CAN_ADC[3];        // 实时 ADC 数据（0x222）
    
    //  ADC 历史数据（ 0x129）
    uint16_t adc_hist[3];
    uint16_t adc_timestamp;
    
    // 错误历史数据（ 0x12A）
    uint16_t err_hist[3];
    uint16_t err_timestamp;
} CAN_data;

typedef struct {
    uint32_t Time;              // 时间
    uint8_t Mutex;              // 锁
} Lock;

extern CAN_data Data;
extern Lock history;
extern Lock ADC_data;
extern Lock heartbeat;

uint8_t Detection(Lock *Ped, uint8_t serial);

#endif