#ifndef __PAGE_SERVO_H
#define __PAGE_SERVO_H

#include "main.h"
#include "input_handler.h"

uint8_t page_servo_enter(void);
void page_servo_exit(void);
uint8_t page_servo_handle_event(InputEvent ev);

#endif