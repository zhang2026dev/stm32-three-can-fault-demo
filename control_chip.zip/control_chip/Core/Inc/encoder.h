#ifndef __ENCODER_H
#define __ENCODER_H

#include "main.h"
#include "menu_manager.h"  // 为了用 InputEvent

void Encoder_Init(void);
InputEvent Encoder_GetEvent(void);

#endif