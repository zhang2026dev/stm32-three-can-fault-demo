#ifndef __MENU_MODULE_H
#define __MENU_MODULE_H

#include "main.h"

// 菜单项结构体
typedef struct 
{
    char* name; //菜单名称
    void(*callback)(); //按键执行的回调函数
} MenuItem;

//菜单结构体
typedef struct 
{
    char* title; //页面标题
    MenuItem* items; //菜单数组  /结构体中的结构体 
    uint8_t count; //菜单数量
    uint8_t selected; //当前选中
} Menu;

//初始化菜单
void Menu_Init(Menu* menu,char * title,MenuItem* items,uint8_t const); //定义一个函数 调用结构体变量 

// 处理菜单事件 （编码器上下，按键）
uint8_t Menu_Process(Menu* menu,InputEvent event);

//显示菜单
void Menu_Show(Menu * menu);

//获取选中的
uint8_t Menu_GetSelected(Menu* menu);
#endif