#ifndef __FAULT_STORAGE_TASK_H
#define __FAULT_STORAGE_TASK_H

#include "internal_flash.h"
#include "main.h"

void StartDefaultTaskaaa(void *pvParameters);
void Test_SendOneFault(void); 
void FaultStorageTask(void *pvParameters);

#endif