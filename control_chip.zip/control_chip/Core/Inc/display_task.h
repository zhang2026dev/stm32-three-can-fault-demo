#ifndef __DISPLAY_TASK_H
#define __DISPLAY_TASK_H

#include "main.h"

void LED_Init(void);
void Display_Menu(uint8_t selection);

#endif