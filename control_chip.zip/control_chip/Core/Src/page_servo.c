#include "page_servo.h"
#include "can_driver.h"
#include "oled.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"

typedef struct 
{
	uint8_t cursor; //光标位置
	uint8_t active; //页面状态
} ServoPageContext;

ServoPageContext ctx = {0};
/*
servo_show_menu 函数 显示加光标位置 
*/
static void servo_show_menu(void)
{
    OLED_ShowString(0, 0, "   ", 16, 0);
    OLED_ShowString(0, 2, "   ", 16, 0);
    OLED_ShowString(0, 4, "   ", 16, 0);
    
    if(ctx.cursor == 0) {
        OLED_ShowString(0, 0, ">0", 16, 0);
        OLED_ShowString(0, 2, " 90", 16, 0);
        OLED_ShowString(0, 4, " 180", 16, 0);
        OLED_ShowString(0, 6, " BACK", 16, 0);
    } else if(ctx.cursor == 1) {
        OLED_ShowString(0, 0, " 0", 16, 0);
        OLED_ShowString(0, 2, ">90", 16, 0);
        OLED_ShowString(0, 4, " 180", 16, 0);
        OLED_ShowString(0, 6, " BACK", 16, 0);
    } else if(ctx.cursor == 2) {
        OLED_ShowString(0, 0, " 0", 16, 0);
        OLED_ShowString(0, 2, " 90", 16, 0);
        OLED_ShowString(0, 4, ">180", 16, 0);
        OLED_ShowString(0, 6, " BACK", 16, 0);
    } else {
        OLED_ShowString(0, 0, " 0", 16, 0);
        OLED_ShowString(0, 2, " 90", 16, 0);
        OLED_ShowString(0, 4, " 180", 16, 0);
        OLED_ShowString(0, 6, ">BACK", 16, 0);
    }
}
/*
send_servo_command can发送 角度
*/
static void send_servo_command(uint8_t angle)
{
    uint8_t data[1] = {angle};
    CAN_TxHeaderTypeDef txHeader;
    txHeader.StdId = 0x123;
    txHeader.RTR = CAN_RTR_DATA;
    txHeader.IDE = CAN_ID_STD;
    txHeader.DLC = 1;
    CAN_TX(&txHeader, data, 1);
		uart_printf("发送成功舵机\n");
}

uint8_t page_servo_enter(void)
{
    ctx.cursor = 0;
    ctx.active = 1;
    OLED_Clear();
    servo_show_menu();
    return 0;
}

void page_servo_exit(void)
{
    ctx.active = 0;
}
/*
page_servo_handle_event判断编码器 
判断是否在舵机页面 
向上 当前 == 0 就= 3 或者 -- 
向下 当前 == 3 就 =0 或者 ++ 
安下 当前 == 3 退出 
否则 发送当前选项 延迟 500
*/
uint8_t page_servo_handle_event(InputEvent ev)
{
    if(!ctx.active) return 0;
    
		if(ev == EVENT_ENCODER_UP) { //上移
        if(ctx.cursor == 0) ctx.cursor = 3;
        else ctx.cursor--;
        servo_show_menu();
    }
    else if(ev == EVENT_ENCODER_DOWN) { //下移
        if(ctx.cursor == 3) ctx.cursor = 0;
        else ctx.cursor++;
        servo_show_menu();
    }
    else if(ev == EVENT_BUTTON_CLICK) {//按下
        if(ctx.cursor == 3) return 1;
        uint8_t angle[] = {0, 90, 180};
        send_servo_command(angle[ctx.cursor]);
        OLED_ShowString(0, 7, "OK", 16, 0);
        vTaskDelay(pdMS_TO_TICKS(500));
        servo_show_menu();
    }
    return 0;
}