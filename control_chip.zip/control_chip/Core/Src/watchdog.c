#include <main.h>
#include <watchdog.h>
#include "FreeRTOS.h"
#include "task.h"
#include "menu_manager.h"
#include "my_debug.h"
#include "internal_flash.h"
FaultType_t g_sys_err_code = FAULT_NONE;
uint8_t g_feed_dog_enable = 1;


//判断是否喂标准位 
void IWDG_Feed(void)
{
    if(g_feed_dog_enable)
    {
        HAL_IWDG_Refresh(&hiwdg);
    }
}

//判断看门狗错误
void WDG_CheckHwReset(void)
{
    if(__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST))
    {
        g_sys_err_code = FAULT_WDG_HW_RESET;
        __HAL_RCC_CLEAR_RESET_FLAGS();
    }
}


/*
数据超时检测
如果 大于8 秒并且标准位开 上锁防止重复打印
不满足条件 开标准位 

参数 : 时间 错误类型 错误编号 
*/

void	Detectionl(uint32_t timl,FaultType_t type,uint32_t serial,uint8_t flag)
{
	uint32_t now = xTaskGetTickCount();
	if((now - timl) > pdMS_TO_TICKS(8000))
	{
		Fault_SendMsg(timl, type, serial,flag);
		g_feed_dog_enable = 0;//关闭看门狗
	}else 
	{
		g_feed_dog_enable = 1;//正常喂狗 
	}
}

//	WDG_CheckHwReset(); //判断看门狗错误
//	
//	uart_printf_init(&huart1);
//	
//	CAN_Init();
//	LED_Init();
//	HAL_IWDG_Init(&hiwdg);
//	HAL_TIM_Base_Start(&htim3);
//	Fault_QueueCreate();
//	
//	xTaskCreate(can_task, "can_task", 512, NULL, 3, NULL);//can接收函数
//	xTaskCreate(menu_show_main, "menu_show_main", 512, NULL, 2, NULL);//菜单页面
//	xTaskCreate(FaultStorageTask, "FaultStorageTask", 512, NULL, 4, NULL);//菜单页面


//void StartDefaultTask(void *argument);
//void can_task(void *pvParameters);
//void CAN_rx_Cs(void *pvParameters);
//void menu_show_main(void *pvParameters);
//void FaultStorageTask(void *pvParameters);
//void Fault_QueueCreate(void);
