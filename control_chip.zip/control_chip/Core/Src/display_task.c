#include "main.h"
#include "display_task.h"
#include "oled.h"
#include "my_debug.h"

void LED_Init(void)
{
    OLED_Init();
    OLED_Clear();
	uart_printf("初始化成功\n");
}

void Display_Menu(uint8_t sel)
{
    const char* items[] = {"dataacquisition", "servo control", "historical data"};
    for(int i = 0; i < 3; i++) {
        OLED_ShowString(0, i*2, (char*)items[i], 16, (i == sel) ? 1 : 0);
    }
}