#include "main.h"
#include "can_driver.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"
#include "can_task.h"
#include "watchdog.h"
#include "internal_flash.h"
#include "string.h"

CAN_data Data = {0};
Lock history = {0};
Lock ADC_data = {0};
Lock heartbeat = {0};

// 检测超时函数
uint8_t Detection(Lock *Ped, uint8_t serial)
{
    uint32_t now = xTaskGetTickCount();
    if ((now - Ped->Time) > pdMS_TO_TICKS(8000)) {
        if (Ped->Mutex == 0) {
            Fault_SendMsg(Ped->Time, FAULT_HEARTBEAT_TIMEOUT, serial, 0);
            Ped->Mutex = 1;
            return 1;
        }
        return 0;
    } else if ((now - Ped->Time) < pdMS_TO_TICKS(8000)) {
        Ped->Mutex = 0;
        return 0;
    }
    return 0;
}

// CAN 接收任务
void can_task(void *pvParameters)
{
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];
    uint32_t last_heartbeat_time = 0;

    while (1) {
        // ========== 1. 超时检测 ==========
        if (Detection(&heartbeat, 1) == 1) {
            uart_printf("心跳超时！\n");
        }
        if (Detection(&ADC_data, 2) == 1) {
            uart_printf("ADC超时！\n");
        }
        if (Detection(&history, 3) == 1) {
            uart_printf("历史数据超时！\n");
        }

        // ========== 2. CAN 接收 ==========
        if (CAN_RX(&rxHeader, rxData)) {
            uart_printf("接收成功\n");
            switch (rxHeader.StdId) {
                // --- 心跳包 ---
                case 0x111:
                    if (rxHeader.DLC >= 8) {
                        heartbeat.Time = xTaskGetTickCount();
                        heartbeat.Mutex = 0;
                        uart_printf("[CAN] 收到心跳包\n");
                    }
                    break;

                // --- ★ 存储芯片上报的 ADC 历史数据（0x129） ---
                case 0x129:
                    if (rxHeader.DLC >= 8) {
                        // rxData[0] = 类型 (0x00)
                        Data.adc_hist[0] = (rxData[1] << 8) | rxData[2];
                        Data.adc_hist[1] = (rxData[3] << 8) | rxData[4];
                        Data.adc_hist[2] = (rxData[5] << 8) | rxData[6];
                        Data.adc_timestamp = rxData[7];
                        uart_printf("[CAN] ADC历史: %d, %d, %d, time=%ds\n",
                            Data.adc_hist[0], Data.adc_hist[1],
                            Data.adc_hist[2], Data.adc_timestamp);
                    }
                    break;

                // --- ★ 存储芯片上报的错误历史数据（0x12A） ---
                case 0x12A:
                    if (rxHeader.DLC >= 8) {
                        history.Time = xTaskGetTickCount();
                        history.Mutex = 0;
                        // rxData[0] = 类型 (0x02)
                        Data.err_hist[0] = (rxData[1] << 8) | rxData[2];
                        Data.err_hist[1] = (rxData[3] << 8) | rxData[4];
                        Data.err_hist[2] = (rxData[5] << 8) | rxData[6];
                        Data.err_timestamp = rxData[7];
                        uart_printf("[CAN] 错误历史: %d, %d, %d, time=%ds\n",
                            Data.err_hist[0], Data.err_hist[1],
                            Data.err_hist[2], Data.err_timestamp);
                    }
                    break;

                // --- 采集芯片发送的 ADC 数据（0x222） ---
                case 0x222:
                    if (rxHeader.DLC >= 8) {
                        ADC_data.Time = xTaskGetTickCount();
                        ADC_data.Mutex = 0;
                        Data.CAN_ADC[0] = (rxData[0] << 8) | rxData[1];
                        Data.CAN_ADC[1] = (rxData[2] << 8) | rxData[3];
                        Data.CAN_ADC[2] = (rxData[4] << 8) | rxData[5];
                        uart_printf("[CAN] 实时ADC: %d, %d, %d\n",
                            Data.CAN_ADC[0], Data.CAN_ADC[1], Data.CAN_ADC[2]);
                    }
                    break;

                case 0x223:
                    uart_printf("[CAN] 收到存储芯片故障回应\n");
                    break;

                // --- 其他未知 ID ---
                default:
                    uart_printf("[CAN] 未知ID: 0x%03X, DLC=%d\n", rxHeader.StdId, rxHeader.DLC);
                    break;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

// 测试用 CAN 接收任务（保留）
void CAN_rx_Cs(void *pvParameters)
{
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];
    uart_printf("执行 CAN_rx_Cs\n");
    while (1) {
        if (CAN_RX(&rxHeader, rxData)) {
            uart_printf("收到 RX: ");
            for (int i = 0; i < rxHeader.DLC; i++) {
                uart_printf("%02X ", rxData[i]);
            }
            uart_printf("\n");
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}