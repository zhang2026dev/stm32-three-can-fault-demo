#include "page_spi.h"
#include "oled.h"
#include "my_debug.h"
#include "can_task.h"

#define SPI_STATE_MENU 0
#define SPI_STATE_ADC_HIST 1
#define SPI_STATE_CAN_ERR 2

typedef struct 
{
    uint8_t active;
    uint8_t state;
    uint8_t menu_sel;
}SpiPageContext;

SpiPageContext ctxe = {0, SPI_STATE_MENU, 0};

/* 显示主菜单 - 只有3个数据+退出，无标题 */
static void spi_show_menu(void)
{
    OLED_Clear();
    
    if (ctxe.menu_sel == 0) {
        OLED_ShowString(0, 0, ">ADC", 16, 1);
        OLED_ShowString(0, 2, " ERR", 16, 0);
        OLED_ShowString(0, 4, " BACK", 16, 0);
    } else if (ctxe.menu_sel == 1) {
        OLED_ShowString(0, 0, " ADC", 16, 0);
        OLED_ShowString(0, 2, ">ERR", 16, 1);
        OLED_ShowString(0, 4, " BACK", 16, 0);
    } else {
        OLED_ShowString(0, 0, " ADC", 16, 0);
        OLED_ShowString(0, 2, " ERR", 16, 0);
        OLED_ShowString(0, 4, ">BACK", 16, 1);
    }
}

/* 显示 ADC 历史数据 */
static void spi_show_adc_history(void)
{
    OLED_Clear();
    char buf[20];
    sprintf(buf, "CH1:%d", Data.adc_hist[0]);
    OLED_ShowString(0, 0, buf, 16, 0);
    sprintf(buf, "CH2:%d", Data.adc_hist[1]);
    OLED_ShowString(0, 2, buf, 16, 0);
    sprintf(buf, "CH3:%d", Data.adc_hist[2]);
    OLED_ShowString(0, 4, buf, 16, 0);
    sprintf(buf, "T:%ds", Data.adc_timestamp);
    OLED_ShowString(0, 6, buf, 16, 0);
}

/* 显示 CAN 错误历史数据 */
static void spi_show_can_error_history(void)
{
    OLED_Clear();
    char buf[20];
    sprintf(buf, "E1:%d", Data.err_hist[0]);
    OLED_ShowString(0, 0, buf, 16, 0);
    sprintf(buf, "E2:%d", Data.err_hist[1]);
    OLED_ShowString(0, 2, buf, 16, 0);
    sprintf(buf, "E3:%d", Data.err_hist[2]);
    OLED_ShowString(0, 4, buf, 16, 0);
    sprintf(buf, "T:%ds", Data.err_timestamp);
    OLED_ShowString(0, 6, buf, 16, 0);
}

uint8_t page_spi_enter(void)
{
    ctxe.active = 1;
    ctxe.state = SPI_STATE_MENU;
    ctxe.menu_sel = 0;
    spi_show_menu();
    return 0;
}

void page_spi_exit(void)
{
    ctxe.active = 0;
}

uint8_t page_spi_handle_event(InputEvent ev)
{
    if (!ctxe.active) return 0;
    
    switch (ctxe.state) {
        case SPI_STATE_MENU:
            switch (ev) {
                case EVENT_ENCODER_UP:
                    if (ctxe.menu_sel > 0) ctxe.menu_sel--;
                    else ctxe.menu_sel = 2;
                    spi_show_menu();
                    break;
                case EVENT_ENCODER_DOWN:
                    if (ctxe.menu_sel < 2) ctxe.menu_sel++;
                    else ctxe.menu_sel = 0;
                    spi_show_menu();
                    break;
                case EVENT_BUTTON_CLICK:
                    if (ctxe.menu_sel == 0) {
                        ctxe.state = SPI_STATE_ADC_HIST;
                        spi_show_adc_history();
                    } else if (ctxe.menu_sel == 1) {
                        ctxe.state = SPI_STATE_CAN_ERR;
                        spi_show_can_error_history();
                    } else {
                        return 1;  // BACK
                    }
                    break;
            }
            break;
            
        case SPI_STATE_ADC_HIST:
        case SPI_STATE_CAN_ERR:
            if (ev == EVENT_BUTTON_CLICK) {
                ctxe.state = SPI_STATE_MENU;
                spi_show_menu();
            }
            break;
    }
    return 0;
}