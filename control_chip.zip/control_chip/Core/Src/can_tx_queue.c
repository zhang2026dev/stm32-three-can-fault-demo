#include "can_tx_queue.h"
#include "my_debug.h"

static QueueHandle_t g_can_tx_queue = NULL;

// CAN发送任务
static void CAN_Send_Task(void *pvParameters)
{
    CanTxMsg_t tx_msg;
    CAN_TxHeaderTypeDef txHeader;

    for (;;) {
        if (xQueueReceive(g_can_tx_queue, &tx_msg, portMAX_DELAY) == pdPASS) {
            txHeader.StdId = tx_msg.id;
            txHeader.DLC = tx_msg.dlc;
            txHeader.IDE = CAN_ID_STD;
            txHeader.RTR = CAN_RTR_DATA;
            CAN_TX(&txHeader, tx_msg.data, tx_msg.dlc);
        }
    }
}

void CAN_Tx_Queue_Init(void)
{
    if (g_can_tx_queue == NULL) {
        g_can_tx_queue = xQueueCreate(32, sizeof(CanTxMsg_t));
        if (g_can_tx_queue != NULL) {
            xTaskCreate(CAN_Send_Task, "CAN_Tx", 256, NULL, 2, NULL);
            uart_printf("[CAN_Tx_Queue] 初始化成功\r\n");
        } else {
            uart_printf("[CAN_Tx_Queue] 队列创建失败！\r\n");
        }
    }
}

void CAN_Send_To_Queue(uint32_t id, uint8_t *data, uint8_t dlc, CanMsgType_t type)
{
    if (g_can_tx_queue == NULL) {
        uart_printf("[CAN_Tx_Queue] 队列未初始化！\r\n");
        return;
    }

    if (dlc > 8) dlc = 8;

    CanTxMsg_t tx_msg;
    tx_msg.type = type;
    tx_msg.id = id;
    tx_msg.dlc = dlc;
    for (uint8_t i = 0; i < dlc; i++) {
        tx_msg.data[i] = data[i];
    }

    if (xQueueSend(g_can_tx_queue, &tx_msg, 0) != pdPASS) {
        uart_printf("[CAN_Tx_Queue] 队列满，丢包 ID=0x%03X\r\n", id);
    }
}