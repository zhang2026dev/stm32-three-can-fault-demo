#include "encoder.h"
#include "my_debug.h"

static uint16_t last_value = 0;

void Encoder_Init(void)
{
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
    last_value = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
}

InputEvent Encoder_GetEvent(void)
{
    static uint16_t last = 0;
    uint16_t now = __HAL_TIM_GET_COUNTER(&htim3);
    InputEvent ev = EVENT_NONE;

    if (now > last) ev = EVENT_ENCODER_UP;
    else if (now < last) ev = EVENT_ENCODER_DOWN;

    last = now;

    if (ev != EVENT_NONE) {
        uart_printf("ENC: %s\n", ev == EVENT_ENCODER_UP ? "UP" : "DOWN");
    }

    return ev;
}