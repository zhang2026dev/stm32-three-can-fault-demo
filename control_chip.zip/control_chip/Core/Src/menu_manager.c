#include "page_spi.h"
#include "watchdog.h"
#include "oled.h"
#include "oledfont.h"
#include "display_task.h"
#include "page_adc.h"
#include "page_servo.h"
#include "watchdog.h"
#include "menu_manager.h"
#include "main.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"
#include "input_handler.h"

uint32_t menu_last_tick = 0; //菜单时间

/**********************************************************
void menu_show_main(void *pvParameters) 页面逻辑判断函数 
定义值: 
STATE_MAIN_MENU        主菜单（选择三个功能）
STATE_DATA_DISPLAY;    数据显示（ADC）
STATE_FAN_CONTROL;     风扇控制
STATE_HISTORY_DATA;    SPI
ev                     编码器值 
select                 旋转值 在第几行 
state                  页面值 

返回值:无

判断逻辑: 
获取编码器值 

1.如果页面值有变化先清空 旧页面 然后进入新页面 
2.判断 旋转编码器 向上是 0 = 2 向下是 2 = 0  其他情况 -- 或者 ++ （边界）
3.如果编码器操作不在首页面 去其他页面判断 其他页面 返回一个值判断是否按下返回  
***********************************************************/

void menu_show_main(void *pvParameters)
{
    uint8_t state = STATE_MAIN_MENU;
    uint8_t last_state = STATE_MAIN_MENU;
    uint8_t select = 0;
		uint8_t menu_monitor_en;
    // 开机显示主菜单
    Display_Menu(select);

    while (1)
    {
        InputEvent ev = input_get_event();

        // ========== 1. 状态变化处理（进入新状态时执行） ==========
        //页面值不等于首页面 
        if (state != last_state) {
            
            // 退出旧状态
            switch (last_state) {
                case STATE_DATA_DISPLAY://adc
                    page_adc_exit();
                    break;
                case STATE_FAN_CONTROL://舵机
                    page_servo_exit();
                    break;
                case STATE_HISTORY_DATA:
                    page_spi_exit();
                    break;
            }
            
            // 进入新状态 刷新 
            switch (state) {
                case STATE_DATA_DISPLAY:
                    page_adc_enter();
                    break;
                case STATE_FAN_CONTROL:
                    page_servo_enter();
                    break;
                case STATE_HISTORY_DATA:
                    page_spi_enter();
                    break;
                case STATE_MAIN_MENU:
                    OLED_Clear();
                    Display_Menu(select);
                    break;
            }
            last_state = state;
        }

        if (state == STATE_DATA_DISPLAY) {
            page_adc_auto_refresh();
        }

        if (ev != EVENT_NONE) //不等于空
        {
            uart_printf("Event: %d, State: %d\n", ev, state);
            
            if (state == STATE_MAIN_MENU) {
                switch (ev)
                {
                    case EVENT_ENCODER_UP:
                        if (select == 0) select = 2;
                        else select--;
                        Display_Menu(select);
                        break;

                    case EVENT_ENCODER_DOWN:
                        if (select >= 2) select = 0;
                        else select++;
                        Display_Menu(select);
                        break;

                    case EVENT_BUTTON_CLICK:
                        switch (select) {
                            case 0: 
                                state = STATE_DATA_DISPLAY;
                                break;
                            case 1: 
                                state = STATE_FAN_CONTROL;
                                break;
                            case 2: 
                                state = STATE_HISTORY_DATA;
                                break;
                        }
                        break;
                }
            } else {
                uint8_t need_exit = 0;
							//获取函数返回值 1 返回主页面 
                switch (state) {
                    case STATE_DATA_DISPLAY:
                        need_exit = page_adc_handle_event(ev);
                        break;
                    case STATE_FAN_CONTROL:
                        need_exit = page_servo_handle_event(ev);
                        break;
                    case STATE_HISTORY_DATA:
                        need_exit = page_spi_handle_event(ev);
                        break;
                }
                if (need_exit) {
                    state = STATE_MAIN_MENU;
                }
            }
        }
				menu_last_tick = xTaskGetTickCount();//读取时间
				
				Detectionl(menu_last_tick,FAULT_MENU_DEAD,1,1);//存

        vTaskDelay(pdMS_TO_TICKS(20));

    }
}