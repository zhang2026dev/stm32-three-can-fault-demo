#include "main.h"
#include "fan_controller.h"
#include "menu_module.h"
#include "oled.h"
#include "my_debug.h"
#include "input_handler.h"
#include "FreeRTOS.h"
#include "task.h"
// 声明外部变量
extern TIM_HandleTypeDef htim3;

 	/**********************************************************
	InputEvent input_get_event(void) 函数 旋转编码器判断
	
	定义值:
	
	返回值:
	
	判断逻辑:
	
	旋转逻辑:
	
  ***********************************************************/

static Menu fan_menu;
static MenuItem fan_items[3];
static uint8_t init_done = 0;
//回调函数
void set_0_degree()
{
    if(!init_done) return;  // 再加一层保护 如果 1就退出
    
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,50); // 输入配置 50 
    OLED_Clear();//清屏
    OLED_ShowString(0,2,"Set to 0 ",16,1);//led输出
    vTaskDelay(pdMS_TO_TICKS(500));
    Menu_Show(&fan_menu);//菜单初始化
}
void set_90_degree()
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,150);
    OLED_Clear();
    OLED_ShowString(0,2,"Set to 90",16,1);
    vTaskDelay(pdMS_TO_TICKS(500));
    Menu_Show(&fan_menu);  //菜单初始化
}

void set_180_degree()
{
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,250);
    OLED_Clear();
    OLED_ShowString(0,2,"Set to 180",16,1);
    vTaskDelay(pdMS_TO_TICKS(500));
    Menu_Show(&fan_menu);  //菜单初始化
}

void fan_controller_init()
{
    uart_printf("=== 进入舵机初始化 ===\n");
    
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);//启动pwm 

    fan_items[0].name = "0"; //赋值给结构体
    fan_items[0].callback = set_0_degree; 

    fan_items[1].name = "90";
    fan_items[1].callback = set_90_degree; 

    fan_items[2].name = "180";
    fan_items[2].callback = set_180_degree; 

    Menu_Init(&fan_menu,"fan Control",fan_items,3);//初始化
    
    uart_printf("显示菜单前\n");
    Menu_Show(&fan_menu);
    uart_printf("显示菜单后\n");
    
    HAL_Delay(500);
    
    init_done = 1;
    uart_printf("=== 舵机初始化完成 ===\n");
}

void fan_controller_update(InputEvent event)
{
    if(!init_done) {
        uart_printf("init未完成，忽略事件: %d\n", event);  // 看看有没有事件被忽略
        return;
    }
    
    if(event != EVENT_NONE)
    {
        uart_printf("fan_controller 收到事件: %d\n", event);  // 看看到底是什么事件
        Menu_Process(&fan_menu, event);
    }
}
