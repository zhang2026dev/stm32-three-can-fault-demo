#include "internal_flash.h"
#include "string.h"
#include "main.h"
#include "my_debug.h"
#include "can_tx_queue.h"

// ========== 全局变量 ==========
QueueHandle_t g_fault_queue = NULL;
FaultRingBuffer_t g_ram_ring = {0};
static uint8_t s_flash_inited = 0;
uint8_t g_sys_flag = 0;

// ========== 私有硬件驱动 ==========
static HAL_StatusTypeDef Flash_Erase_Page(uint32_t PageAddr)
{
    FLASH_EraseInitTypeDef EraseInit = {
        .TypeErase = FLASH_TYPEERASE_PAGES,
        .PageAddress = PageAddr,
        .NbPages = 1
    };
    uint32_t PageError = 0;
    return HAL_FLASHEx_Erase(&EraseInit, &PageError);
}

static HAL_StatusTypeDef Flash_Write_Word(uint32_t Address, uint32_t Data)
{
    return HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, Address, Data);
}

static HAL_StatusTypeDef internal_flash_write(uint32_t dest_addr, void *p_src, uint32_t len_byte)
{
    if (len_byte % 4) return HAL_ERROR;
    uint32_t *src = (uint32_t *)p_src;
    for (uint32_t i = 0; i < len_byte / 4; i++)
    {
        if(Flash_Write_Word(dest_addr + i * 4, src[i]) != HAL_OK)
            return HAL_ERROR;
    }
    return HAL_OK;
}

static void internal_flash_read(uint32_t src_addr, void *p_dst, uint32_t len_byte)
{
    memcpy(p_dst, (void *)src_addr, len_byte);
}

// ========== 初始化入口 ==========
void InternalFlash_Init(void)
{
    uart_printf("[INIT] InternalFlash_Init 开始\r\n");
    if(s_flash_inited) {
        uart_printf("[INIT] 已初始化过，跳过\r\n");
        return;
    }
    Fault_QueueCreate();
    Flash_Recover_RingBuffer();
    s_flash_inited = 1;
    uart_printf("[INIT] InternalFlash_Init 完成\r\n");
}

// ========== 队列创建 ==========
void Fault_QueueCreate(void)
{
    if(g_fault_queue == NULL) {
        g_fault_queue = xQueueCreate(8, sizeof(FaultMsg_t));
        if(g_fault_queue != NULL) {
            uart_printf("[QUEUE] 队列创建成功，深度8\r\n");
        } else {
            uart_printf("[QUEUE] 队列创建失败！\r\n");
        }
    } else {
        uart_printf("[QUEUE] 队列已存在\r\n");
    }
}

// ========== 发送故障到队列（入队） ==========
BaseType_t Fault_SendMsg(uint32_t time, FaultType_t type, uint32_t err, uint8_t flag)
{
    uart_printf("[QUEUE_IN] 准备入队: type=%d err=%lu time=%lu flag=%d\r\n", type, err, time, flag);
    
    g_sys_flag = flag;
    if (g_fault_queue == NULL) {
        uart_printf("[QUEUE_IN] 队列为空，入队失败！\r\n");
        return pdFAIL;
    }
    
    FaultMsg_t msg = {type, err, time};
    BaseType_t ret = xQueueSend(g_fault_queue, &msg, 0);
    
    if (ret == pdPASS) {
        uart_printf("[QUEUE_IN] 入队成功！当前队列可用空间: %d\r\n", uxQueueSpacesAvailable(g_fault_queue));
    } else {
        uart_printf("[QUEUE_IN] 入队失败！队列已满\r\n");
    }
    return ret;
}

// ========== 环形缓冲区操作（无锁） ==========

// 压入一条消息到环形缓冲区
uint8_t RingBuffer_Push(FaultMsg_t *pMsg)
{
    uart_printf("[RING_PUSH] 准备压入: type=%d err=%lu\r\n", pMsg->type, pMsg->err);

    g_ram_ring.buf[g_ram_ring.write_index] = *pMsg;
    uart_printf("[RING_PUSH] 写入位置 write_index=%d\r\n", g_ram_ring.write_index);
    
    g_ram_ring.write_index = (g_ram_ring.write_index + 1) % FAULT_BUF_MAX;
    if (g_ram_ring.valid_cnt < FAULT_BUF_MAX)
        g_ram_ring.valid_cnt++;

    uint8_t ret = (g_ram_ring.valid_cnt == FAULT_BUF_MAX) ? 1 : 0;
    
    uart_printf("[RING_PUSH] 当前 valid_cnt=%d 是否已满=%d\r\n", g_ram_ring.valid_cnt, ret);
    return ret;
}

// 取出最旧一条消息（用于调试/重发）
uint8_t RingBuffer_Pop(FaultMsg_t *pMsg)
{
    if(pMsg == NULL) {
        uart_printf("[RING_POP] 传入指针为空\r\n");
        return 0;
    }

    if(g_ram_ring.valid_cnt == 0)
    {
        uart_printf("[RING_POP] 缓冲区为空\r\n");
        return 0;
    }

    uint8_t read_idx = (g_ram_ring.write_index - g_ram_ring.valid_cnt + FAULT_BUF_MAX) % FAULT_BUF_MAX;
    *pMsg = g_ram_ring.buf[read_idx];
    g_ram_ring.valid_cnt--;
    
    uart_printf("[RING_POP] 取出数据: type=%d err=%lu time=%lu 剩余=%d\r\n", 
        pMsg->type, pMsg->err, pMsg->time, g_ram_ring.valid_cnt);

    return 1;
}

uint8_t RingBuffer_GetCount(void)
{
    return g_ram_ring.valid_cnt;
}

uint8_t RingBuffer_IsFull(void)
{
    return (g_ram_ring.valid_cnt == FAULT_BUF_MAX) ? 1 : 0;
}

void RingBuffer_Clear(void)
{
    g_ram_ring.write_index = 0;
    g_ram_ring.valid_cnt = 0;
    uart_printf("[RING] 缓冲区已清空\r\n");
}

FaultRingBuffer_t* Fault_GetRingBuffer(void)
{
    return &g_ram_ring;
}

// ========== Flash存储接口 ==========

// 将环形缓冲区全部写入Flash
HAL_StatusTypeDef Flash_Store_RingBuffer(void)
{
    uart_printf("[FLASH_STORE] 开始存储...\r\n");
    
    if (RingBuffer_GetCount() == 0) {
        uart_printf("[FLASH_STORE] 缓冲区为空，不存储\r\n");
        return HAL_ERROR;
    }
    
    FaultRingBuffer_t temp_buf;

    // 直接拷贝，无锁
    memcpy(&temp_buf, &g_ram_ring, sizeof(FaultRingBuffer_t));
    
    uart_printf("[FLASH_STORE] 待存储数据: valid_cnt=%d\r\n", temp_buf.valid_cnt);
    for (uint8_t i = 0; i < temp_buf.valid_cnt; i++) {
        uart_printf("[FLASH_STORE] 数据[%d]: type=%d err=%lu time=%lu\r\n", 
            i, temp_buf.buf[i].type, temp_buf.buf[i].err, temp_buf.buf[i].time);
    }

    HAL_FLASH_Unlock();
    uart_printf("[FLASH_STORE] Flash解锁成功\r\n");
    
    uart_printf("[FLASH_STORE] 开始擦除页: 0x%08X\r\n", INTERNAL_FLASH_FAULT_PAGE_ADDR);
    HAL_StatusTypeDef ret = Flash_Erase_Page(INTERNAL_FLASH_FAULT_PAGE_ADDR);
    if (ret != HAL_OK) {
        uart_printf("[FLASH_STORE] 擦除失败！ret=%d\r\n", ret);
        HAL_FLASH_Lock();
        return ret;
    }
    uart_printf("[FLASH_STORE] 擦除成功\r\n");
    
    if (ret == HAL_OK)
    {
        uint32_t header[2] = {FLASH_MAGIC, temp_buf.valid_cnt};
        uart_printf("[FLASH_STORE] 写入头部: magic=0x%08X valid_cnt=%d\r\n", header[0], header[1]);
        ret = internal_flash_write(INTERNAL_FLASH_FAULT_PAGE_ADDR, header, 8);
        
        if (ret == HAL_OK)
        {
            uart_printf("[FLASH_STORE] 写入数据区: 地址=0x%08X 大小=%lu\r\n", 
                INTERNAL_FLASH_FAULT_PAGE_ADDR + 8, sizeof(temp_buf.buf));
            ret = internal_flash_write(INTERNAL_FLASH_FAULT_PAGE_ADDR + 8, temp_buf.buf, sizeof(temp_buf.buf));
        }
    }
    
    HAL_FLASH_Lock();
    uart_printf("[FLASH_STORE] Flash锁定\r\n");

    if (ret == HAL_OK)
    {
        uart_printf("[FLASH_STORE] >>> 存储成功！共 %d 条记录\r\n", temp_buf.valid_cnt);
    }
    else
    {
        uart_printf("[FLASH_STORE] >>> 存储失败！ret=%d\r\n", ret);
    }
    return ret;
}

// 上电从Flash恢复到RAM环形缓冲区
void Flash_Recover_RingBuffer(void)
{
    uart_printf("[FLASH_RECOVER] 开始恢复...\r\n");
    
    uint32_t magic = 0;
    internal_flash_read(INTERNAL_FLASH_FAULT_PAGE_ADDR, &magic, 4);
    uart_printf("[FLASH_RECOVER] 读取魔数: 0x%08X (期望: 0x%08X)\r\n", magic, FLASH_MAGIC);
    
    if (magic != FLASH_MAGIC)
    {
        RingBuffer_Clear();
        uart_printf("[FLASH_RECOVER] 魔数不匹配，Flash未初始化或无有效数据\r\n");
        return;
    }

    // 直接读写，无锁（调度器未启动，无竞争）
    internal_flash_read(INTERNAL_FLASH_FAULT_PAGE_ADDR + 4, &g_ram_ring.valid_cnt, 4);
    uart_printf("[FLASH_RECOVER] 读取 valid_cnt=%d\r\n", g_ram_ring.valid_cnt);
    
    if (g_ram_ring.valid_cnt > FAULT_BUF_MAX) {
        uart_printf("[FLASH_RECOVER] valid_cnt 越界，修正为 %d\r\n", FAULT_BUF_MAX);
        g_ram_ring.valid_cnt = FAULT_BUF_MAX;
    }

    internal_flash_read(INTERNAL_FLASH_FAULT_PAGE_ADDR + 8, g_ram_ring.buf, sizeof(g_ram_ring.buf));
    g_ram_ring.write_index = g_ram_ring.valid_cnt % FAULT_BUF_MAX;

    uart_printf("[FLASH_RECOVER] 恢复完成: valid_cnt=%d write_index=%d\r\n", 
        g_ram_ring.valid_cnt, g_ram_ring.write_index);
    
    for (uint8_t i = 0; i < g_ram_ring.valid_cnt; i++)
    {
        uart_printf("[FLASH_RECOVER] 数据[%d]: type=%d err=%lu time=%lu\r\n",
            i, g_ram_ring.buf[i].type, g_ram_ring.buf[i].err, g_ram_ring.buf[i].time);
    }
}



void SendAllFaultsFromRing(void)
{
    FaultRingBuffer_t *pRing = Fault_GetRingBuffer();
    
    // 1. 检查缓冲区是否有效
    if (pRing->valid_cnt == 0) {
        uart_printf("[上电发送] 缓冲区为空，无历史数据\n");
        return;
    }
    
    if (pRing->valid_cnt > FAULT_BUF_MAX) {
        uart_printf("[上电发送] 错误: valid_cnt=%d 超出范围！\n", pRing->valid_cnt);
        RingBuffer_Clear();
        return;
    }
    
    // 2. 打印恢复的数据
    uart_printf("[上电发送] 恢复 %d 条历史故障:\n", pRing->valid_cnt);
    for (uint8_t i = 0; i < pRing->valid_cnt; i++) {
        FaultMsg_t *pMsg = &pRing->buf[i];
        uart_printf("  [%d] type=%d err=%lu time=%lu\n", 
            i, pMsg->type, pMsg->err, pMsg->time);
    }
    
    // 3. 发送数据
    uart_printf("[上电发送] 开始发送 %d 条历史故障到存储芯片\n", pRing->valid_cnt);
    
    for (uint8_t i = 0; i < pRing->valid_cnt; i++) {
        uint8_t txData[8];
        FaultMsg_t *pMsg = &pRing->buf[i];

        txData[0] = (uint8_t)pMsg->type;
        txData[1] = (uint8_t)(pMsg->err >> 0);
        txData[2] = (uint8_t)(pMsg->err >> 8);
        txData[3] = (uint8_t)(pMsg->err >> 16);
        txData[4] = (uint8_t)(pMsg->err >> 24);
        txData[5] = (uint8_t)(pMsg->time >> 0);
        txData[6] = (uint8_t)(pMsg->time >> 8);
        txData[7] = (uint8_t)(pMsg->time >> 16);

        CAN_Send_To_Queue(0x223, txData, 8, MSG_TYPE_FAULT);

        uart_printf("[上电发送] 已发送: type=%d, err=%lu, time=%lu\n",
            pMsg->type, pMsg->err, pMsg->time);
    }

    // 4. 发送完成后清空缓冲区
    RingBuffer_Clear();
    uart_printf("[上电发送] 发送完成，缓冲区已清空\n");
}
