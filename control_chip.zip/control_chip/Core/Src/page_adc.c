#include "page_adc.h"
#include "can_task.h"
#include "oled.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"


typedef struct
{
	uint8_t cursor; //退出或者刷新状态
	uint8_t active;	//当前页面状态 
	uint32_t last_refresh; //时间
}ADCPageContext;

static ADCPageContext ctx = {0};

/*
adc_show_numbers 显示adc数据  

buf[10] 存数据 
sprintf把 ADC数据 存入buf
显示 adc数据  

*/

static void adc_show_numbers(void)
{
    char buf[10];
    uart_printf("adc_show_numbers: %d %d %d\n", Data.CAN_ADC[0] , Data.CAN_ADC[1] ,Data.CAN_ADC[2] );
    for(int i = 0; i < 3; i++) {
        sprintf(buf, "%4d", Data.CAN_ADC[i]);
        OLED_ShowString(40, i*2, buf, 16, 0);
    }
}

static void adc_show_menu(void)
{
    if(ctx.cursor  == 0) {
        OLED_ShowString(0, 6, ">BACK", 16, 0);
        OLED_ShowString(40, 6, "REFRESH", 16, 0);
    } else {
        OLED_ShowString(0, 6, " BACK", 16, 0);
        OLED_ShowString(40, 6, ">REFRESH", 16, 0);
    }
}

/*
page_adc_enter();
记录时间和显示字符  然后刷新 数据
*/
uint8_t page_adc_enter(void)
{
    ctx.cursor = 0;
    ctx.active = 1;
    ctx.last_refresh = xTaskGetTickCount();
    OLED_Clear();
    OLED_ShowString(0, 0, "ADC1:", 16, 0);
    OLED_ShowString(0, 2, "ADC2:", 16, 0);
    OLED_ShowString(0, 4, "ADC3:", 16, 0);
    adc_show_numbers();
    adc_show_menu();
    return 0;
}

void page_adc_exit(void)
{
    ctx.active = 0;
    //判断是否在adc页面 
}
/*
page_adc_auto_refresh函数 延迟函数 

now 当前时间 
判断 当前时间 和 过去时间 是否大于 200 
如果 adc_active 在adc页面 就 刷新时间 
*/
void page_adc_auto_refresh(void)
{
    uint32_t now = xTaskGetTickCount();
    if (now - ctx.last_refresh >= pdMS_TO_TICKS(100)) {
			uart_printf("准备刷新数据, diff=%d\n", now - ctx.last_refresh);
        if (ctx.active) {
            adc_show_numbers();
            ctx.last_refresh = now;
        }
    }
}
/*
判断adc_active首页面 是否激活 

编码器判断 是否上下 移动 
如果 上下 就把退出状态取反 
并且显示 退出 
如果按下
如果是 退出页面 adc_cursor == 0; 就退出 
如果不是就刷新数据 
*/
uint8_t page_adc_handle_event(InputEvent ev)
{
    if(!ctx.active) return 0;
    
    if(ev == EVENT_ENCODER_UP || ev == EVENT_ENCODER_DOWN) {
        ctx.cursor = !ctx.cursor;
        adc_show_menu();
    }
    else if(ev == EVENT_BUTTON_CLICK) {
        if(ctx.cursor == 0) return 1;
        adc_show_numbers();
        adc_show_menu();
    }
    return 0;
}