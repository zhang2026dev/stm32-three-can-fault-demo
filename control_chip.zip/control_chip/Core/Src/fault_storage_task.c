#include "fault_storage_task.h"
#include "can_tx_queue.h"
#include "my_debug.h"


void FaultStorageTask(void *pvParameters)
{
    (void)pvParameters;
    FaultMsg_t recv_msg;

    uart_printf("[FaultStorageTask] 任务启动\r\n");

    for (;;) {
        if (xQueueReceive(g_fault_queue, &recv_msg, portMAX_DELAY) == pdPASS) {
            uart_printf("[TASK] 出队: type=%d err=%lu time=%lu\r\n", 
                recv_msg.type, recv_msg.err, recv_msg.time);

            // 1. 压入环形缓冲区
            uint8_t is_full = RingBuffer_Push(&recv_msg);

            // 2. 判断是否触发存储：满2条 OR 紧急标志置1
            if (is_full == 1 || g_sys_flag == 1) {
                uart_printf("[TASK] 触发存储: is_full=%d, flag=%d\r\n", is_full, g_sys_flag);

                HAL_StatusTypeDef store_ret = Flash_Store_RingBuffer();

                if (store_ret == HAL_OK) {
                    uart_printf("[TASK] 存储成功\r\n");

                    // 先获取数据发送，再清空缓冲区 
                    FaultRingBuffer_t *pRing = Fault_GetRingBuffer();
                    if (pRing->valid_cnt > 0) {
                        uart_printf("[TASK] 准备发送 %d 条故障到存储芯片\n", pRing->valid_cnt);
                        
                        for (uint8_t i = 0; i < pRing->valid_cnt; i++) {
                            uint8_t txData[8];
                            FaultMsg_t *pMsg = &pRing->buf[i];

                            // 打包 8 字节数据：type(1) + err(4) + time(3)
                            txData[0] = (uint8_t)pMsg->type;
                            txData[1] = (uint8_t)(pMsg->err >> 0);
                            txData[2] = (uint8_t)(pMsg->err >> 8);
                            txData[3] = (uint8_t)(pMsg->err >> 16);
                            txData[4] = (uint8_t)(pMsg->err >> 24);
                            txData[5] = (uint8_t)(pMsg->time >> 0);
                            txData[6] = (uint8_t)(pMsg->time >> 8);
                            txData[7] = (uint8_t)(pMsg->time >> 16);

                            // 发送到存储芯片（ID = 0x223）
                            CAN_Send_To_Queue(0x223, txData, 8, MSG_TYPE_FAULT);

                            uart_printf("[TASK] 已发送: type=%d, err=%lu, time=%lu\n",
                                pMsg->type, pMsg->err, pMsg->time);
                        }
                        uart_printf("[TASK] 所有故障发送完成\n");
                    } else {
                        uart_printf("[TASK] 警告: valid_cnt=0, 没有数据可发送\n");
                    }

                    // ★★★ 发送完成后再清空缓冲区 ★★★
                    RingBuffer_Clear();
                    g_sys_flag = 0;
                    uart_printf("[TASK] 缓冲区已清空，紧急标志已复位\n");

                } else {
                    uart_printf("[TASK] 存储失败！ret=%d\n", store_ret);
                }
            }
        }
    }
}
//测试函数：
void Test_SendOneFault(void)
{
    FaultMsg_t msg;
    
    // 1. 从队列取一条数据（不阻塞，0等待）
    if (xQueueReceive(g_fault_queue, &msg, 0) == pdPASS) {
        uint8_t txData[8];
        
        // 2. 打包成 CAN 数据（和之前发送格式一样）
        txData[0] = (uint8_t)msg.type;
        txData[1] = (uint8_t)(msg.err >> 0);
        txData[2] = (uint8_t)(msg.err >> 8);
        txData[3] = (uint8_t)(msg.err >> 16);
        txData[4] = (uint8_t)(msg.err >> 24);
        txData[5] = (uint8_t)(msg.time >> 0);
        txData[6] = (uint8_t)(msg.time >> 8);
        txData[7] = (uint8_t)(msg.time >> 16);
        
        // 3. 发送到存储芯片（ID = 0x223）
        CAN_Send_To_Queue(0x223, txData, 8, MSG_TYPE_FAULT);
        
        uart_printf("[测试] 已发送1条故障: type=%d, err=%lu, time=%lu\n", 
            msg.type, msg.err, msg.time);
    } else {
        uart_printf("[测试] 队列为空，无故障数据可发送\n");
    }
}
void StartDefaultTaskaaa(void *pvParameters)
{
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(5000));  
        Test_SendOneFault();              // 发一条
        vTaskDelay(pdMS_TO_TICKS(5000));  
        Test_SendOneFault();            
        vTaskDelay(pdMS_TO_TICKS(10000)); 
    }
}