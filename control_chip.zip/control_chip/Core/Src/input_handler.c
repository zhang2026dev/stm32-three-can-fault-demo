
 	/**********************************************************
	InputEvent input_get_event(void) 函数 旋转编码器判断
	
	定义值:
	last_cnt = 0; 				//反抖记录
	debounce_counter = 0;	//反抖记录
	stable_cnt = 0; 			//旋转记录
	last_print = 0;				//打印
	
	返回值:
	EVENT_ENCODER_DOWN  向下 
	EVENT_ENCODER_UP    向上
	EVENT_NONE 					无
	EVENT_BUTTON_CLICK 	按下
	
	防抖逻辑:两次值一样 判断稳定 
	
	旋转逻辑:
	稳定后比较当前值和上一次稳定值：
	
  2 → 0  或  数值增加  → UP
  0 → 2  或  数值减少  → DOWN 
	
	返回 值 复编码器值 防抖逻辑清空 
  ***********************************************************/
	
#include "input_handler.h"
#include "main.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"

extern TIM_HandleTypeDef htim3;



InputEvent input_get_event(void) {
	
    static uint8_t last_cnt = 0;
    static uint8_t debounce_counter = 0;
    static uint8_t stable_cnt = 0;
    static uint16_t last_print = 0;
    
    // 编码器处理（保持不变）
    uint16_t raw = __HAL_TIM_GET_COUNTER(&htim3);
    uint8_t cnt = raw % 3;
    
    last_print++;
    if(last_print >= 100) {
        last_print = 0;
    }
    
		//最少等待两次 
    if(cnt == last_cnt) {
        debounce_counter++;
    } else {
        last_cnt = cnt;
        debounce_counter = 0;
    }
    
		//cnt ！= stable_cnt发生变化
    if (debounce_counter >= 2 && cnt != stable_cnt) {
        uint8_t direction;
        
        if (stable_cnt == 2 && cnt == 0) { 
            direction = EVENT_ENCODER_DOWN;
        } else if (stable_cnt == 0 && cnt == 2) {
            direction = EVENT_ENCODER_UP;
        } else if (cnt > stable_cnt) {
            direction = EVENT_ENCODER_DOWN;
        } else {
            direction = EVENT_ENCODER_UP;
        }
        stable_cnt = cnt;
        debounce_counter = 0;
        return direction; 
    }

    static uint8_t button_state = 0;      // 0=空闲, 1=按下等待释放
    static uint32_t press_time = 0;
    
    uint8_t button_pressed = (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == GPIO_PIN_RESET);
    
    switch (button_state) {
        case 0:  // 空闲状态
            if (button_pressed) {
                button_state = 1;
                press_time = xTaskGetTickCount();  // 记录按下时间
            }
            break;
            
        case 1:  // 按下等待释放
            if (!button_pressed) {
                // 按键释放，检查是否是短按
                uint32_t duration = xTaskGetTickCount() - press_time;
                if (duration < pdMS_TO_TICKS(1000)) {  // 小于1秒算短按
                    button_state = 0;
                    return EVENT_BUTTON_CLICK;
                } else {

                    button_state = 0;
                }
            }
            break;
    }
    
    return EVENT_NONE;
}