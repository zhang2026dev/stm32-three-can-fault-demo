#include "can_driver.h"
#include "can_request.h"
#include "can_tx_queue.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"

void request_adc_history(uint8_t page)
{
    uint8_t txData[8] = {0};
    txData[0] = CMD_GET_ADC_HIST;
    txData[1] = page;

    CAN_Send_To_Queue(0x125, txData, 8, MSG_TYPE_HISTORY_ADC);
}

void request_can_history(uint8_t page)
{
    uint8_t txData[8] = {0};
    txData[0] = CMD_GET_CAN_HIST;
    txData[1] = page;

    CAN_Send_To_Queue(0x127, txData, 8, MSG_TYPE_HISTORY_CAN);
}
