#include "menu_module.h"
#include "oled.h"
#include "my_debug.h"
//初始化 
void Menu_Init(Menu* menu,char * title,MenuItem* items,uint8_t count)
{
    //通过指针 指向原始地址 做更新或者跟改 
    //因为函数有生命周期 
    menu->title = title;//存标题
    menu->items = items;//存菜单
    menu->count = count;//存数量
    menu->selected = 0;//默认选择0 
}
//菜单初始化
void Menu_Show(Menu* menu)
{
    OLED_Clear();
    //显示标题 
    OLED_ShowString(0, 0, menu->title, 16, 1);

    //显示菜单
    for (int i = 0; i < menu->count; i++) {
        // 先清空这一行（避免残留）
        OLED_ShowString(0, 2 + i * 2, "                ", 16, 0);  // 16个空格清空
        
        if (i == menu->selected) {
            OLED_ShowString(0, 2 + i * 2, ">", 16, 1);
            OLED_ShowString(12, 2 + i * 2, menu->items[i].name, 16, 1);
        } else {
            OLED_ShowString(12, 2 + i * 2, menu->items[i].name, 16, 0);
        }
    }
}

uint8_t Menu_Process(Menu* menu, InputEvent event)
{
    uint8_t changed = 0;
    
    uart_printf("Menu_Process 收到事件: %d\n", event);  // 加这行

    switch (event)
    {
    case EVENT_ENCODER_UP:
        uart_printf("处理 UP 事件\n");  // 加这行
        if (menu->selected > 0) {
            menu->selected--;
            changed = 1;
        } else {
            menu->selected = menu->count - 1;
            changed = 1;
        }
        break;
        
    case EVENT_ENCODER_DOWN:
        uart_printf("处理 DOWN 事件\n");  // 加这行
        if (menu->selected < menu->count - 1) {
            menu->selected++;
            changed = 1;
        } else {
            menu->selected = 0;
            changed = 1;
        }
        break;
        
    case EVENT_BUTTON_CLICK:
        uart_printf("处理 CLICK 事件\n");  // 加这行
        if(menu->items[menu->selected].callback != NULL) {
            menu->items[menu->selected].callback();
        }
        break;
    }
    
    if (changed) {
        uart_printf("菜单变化，重新显示\n");  // 加这行
        Menu_Show(menu);
    }
    
    return menu->selected;  
}
uint8_t Menu_GetSelected(Menu* menu)
{
    return menu->selected;
}