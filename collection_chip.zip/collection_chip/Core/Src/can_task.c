#include "main.h"
#include "can_driver.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"
#include "fan_controller.h"

void can_task(void *pvParameters)
{
	uart_printf("=== can_task started ===\n");
    CAN_RxHeaderTypeDef rxHeder;
    uint8_t rxdata[8] = {0};
    
    uart_printf("CAN Task started\n");

    while (1)
    {
        if (CAN_RX(&rxHeder, rxdata))
        {
					uart_printf("RX ID:0x%03X\n", rxHeder.StdId);  // 不管什么 ID 都打印
            if (rxHeder.StdId == 0x123 && rxHeder.DLC >= 1)
            {
                uint8_t angle = rxdata[0];
                servo_set_angle(angle);
                uart_printf("Servo: %d\n", angle);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}