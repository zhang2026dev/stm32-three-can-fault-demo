#include "fan_controller.h"
#include "my_debug.h"

extern TIM_HandleTypeDef htim3;

// 设置舵机角度 (0, 90, 180)
void servo_set_angle(uint8_t angle)
{
    uint16_t pulse;
    
    // 固定角度转脉宽
    switch(angle) {
			uart_printf("收到舵机%d\n",angle);
        case 0:   pulse = 50;  break;
        case 90:  pulse = 150; break;
        case 180: pulse = 250; break;
        default:  pulse = 150; break;
    }
    
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulse);
    uart_printf("Servo set to %d degree, pulse=%d\n", angle, pulse);
}

// 初始化舵机
void fan_controller_init(void)
{
    uart_printf("Servo init...\n");
    
    // 启动 PWM
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    
    // 设置初始0度
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 50);
    
    uart_printf("Servo init done\n");
}