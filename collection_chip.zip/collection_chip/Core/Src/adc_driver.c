 #include "can_driver.h"
 #include "main.h"
 #include "my_debug.h"
 #include "adc_driver.h"
 
 //adc值 
 uint16_t g_adc_values[ADC_BUFFER_SIZE];
 
void ADC_Init(void)
{
	//交准 
	HAL_ADCEx_Calibration_Start(&hadc1);
	//启动 adc dma 缓冲区 g_adc_values
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)g_adc_values, ADC_BUFFER_SIZE);
	  
	
}	