#include "adc_task.h"
#include "adc_driver.h"
#include "can_driver.h"
#include "my_debug.h"
#include "FreeRTOS.h"
#include "task.h"
#include <string.h>
#include "main.h"
QueueHandle_t can_tx_queue;

//发送函数
void task_can_transmit(void *pvParameters) {
	CanTxMsg_t Msg ;
	while(1)
	{
		//队里取一条信息 等待 
		if(xQueueReceive(can_tx_queue,&Msg,0))
		{
			CAN_TxHeaderTypeDef txHeader;
			txHeader.StdId = Msg.id;
			txHeader.DLC = Msg.dlc;
			txHeader.RTR = CAN_RTR_DATA;
			txHeader.IDE = CAN_ID_STD;
			CAN_TX(&txHeader,Msg.data,Msg.dlc);
			uart_printf("发送\n");
			uart_printf("ID:%X\n",Msg.id);
			uart_printf("大小:%d\n",Msg.dlc);
			uart_printf("数据:");
			for(int i = 0; i<8;i++)
			{
				uart_printf("%02X",Msg.data[i]);
			}
			uart_printf("\n");
		}		
		HAL_IWDG_Refresh(&hiwdg);//发送完成喂狗
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
}

//adc数据采集 打包
void adc_data(void *pvParameters)
{
	CanTxMsg_t Msg;
	Msg.id = 0x222;
	Msg.dlc = 8;
	while(1)
	{
		Msg.data[0] = 0xFF &(g_adc_values[0] >> 8 );
		Msg.data[1] = 0xFF & g_adc_values[0];
		Msg.data[2] = 0xFF &(g_adc_values[1] >> 8 );
		Msg.data[3] = 0xFF & g_adc_values[1];
		Msg.data[4] = 0xFF &(g_adc_values[2] >> 8 );
		Msg.data[5] = 0xFF & g_adc_values[2];
		Msg.data[6] = 0;
		Msg.data[7] = 0;
		
		if(xQueueSend(can_tx_queue,&Msg,0) != pdPASS)
		{
			uart_printf("ADC队列满了\n");
		}
		vTaskDelay(pdMS_TO_TICKS(2000));
	}

}

//心跳
void task(void *pvParameters)
{
	CanTxMsg_t Msg;
	Msg.id = 0x111;
	Msg.dlc = 8;
	for(int i = 0;i<8;i++)
	{
		Msg.data[i] = 1;
	}
	while(1)
	{
		if(xQueueSend(can_tx_queue,&Msg,0) != pdPASS)
		{
			uart_printf("心跳队列满了\n");
		}
		vTaskDelay(pdMS_TO_TICKS(4000));
	}
}

//测试
void CAN_TX_Cs(void *pvParameters)
{
	
	
	while(1)
	{
		uart_printf("启动成功\n");
		uint8_t arr[8] = {1,1,1,1,1,1,1,1};
		CAN_TxHeaderTypeDef txHeader;
		txHeader.StdId = 0x222;
		txHeader.DLC = 8;
		txHeader.RTR = CAN_RTR_DATA;
		txHeader.IDE = CAN_ID_STD;
		
		CAN_TX(&txHeader,arr,8);
		
		vTaskDelay(pdMS_TO_TICKS(1000));
	}

}