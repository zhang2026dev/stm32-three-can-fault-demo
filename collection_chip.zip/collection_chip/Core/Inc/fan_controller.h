#ifndef __FAN_CONTROLLER_H
#define __FAN_CONTROLLER_H

#include "main.h"

void fan_controller_init(void);
void servo_set_angle(uint8_t angle);

#endif