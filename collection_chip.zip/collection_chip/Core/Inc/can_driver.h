 #ifndef CAN_DRIVER_H
 #define CAN_DRIVER_H

 #include "main.h"
 extern CAN_HandleTypeDef hcan;
 //1.据柄 2.内容 3 .大小
 void CAN_TX(CAN_TxHeaderTypeDef *txHeader,uint8_t *ltxData,uint8_t len);
 uint8_t CAN_RX(CAN_RxHeaderTypeDef *rxHeader ,uint8_t *lrxData);
 void CAN_Init(void);
 void CAN_Recovery(void);
 #endif
 
 
 
 