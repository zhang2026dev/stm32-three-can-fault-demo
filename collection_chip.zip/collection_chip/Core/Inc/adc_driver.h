#ifndef __ADC_DRIVER_H
#define __ADC_DRIVER_H

#include "main.h"

#define ADC_BUFFER_SIZE 3

extern uint16_t g_adc_values[ADC_BUFFER_SIZE];

void ADC_Init(void);

#endif
 