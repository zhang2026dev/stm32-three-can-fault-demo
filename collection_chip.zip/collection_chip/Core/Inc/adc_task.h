 #ifndef ADC_DRIVER_H
 #define ADC_DRIVER_H

 #include "main.h"
 #include "adc_driver.h"
 #include "can_driver.h"
 #include "my_debug.h"
 #include "adc_task.h"
 #include "FreeRTOS.h"
 #include "task.h"
 #include "queue.h"
 
void CAN_TX_Cs(void *pvParameters);
 void adc_data(void *pvParameters); //adc数据
 void task(void *pvParameters); //心跳
 void task_can_transmit(void *pvParameters);
 extern uint8_t adc_txdata[8];//adcx数据 
 extern QueueHandle_t can_tx_queue;
 
 typedef struct {
    uint32_t id;        // CAN ID
    uint8_t data[8];    // 数据内容
    uint8_t dlc;        // 数据长度
} CanTxMsg_t;

 #endif
 